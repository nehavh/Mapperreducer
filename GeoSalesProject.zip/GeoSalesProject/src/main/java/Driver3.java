import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Driver3 {
    public static  void main(String[] args) throws Exception {
        // instantiate a configuration
        Configuration configuration = new Configuration();

        // instantiate a job
        Job job = Job.getInstance(configuration, "Word Count");

        // set job parameters
        job.setPartitionerClass(CustomPartitioner.class);
        job.setJarByClass(MinMaxUnitsSold.class);
        job.setMapperClass(MinMaxUnitsSold.CountMapper.class);
        // job.setCombinerClass(MinMaxUnitsSold.CountReducer.class);
        job.setReducerClass(MinMaxUnitsSold.CountReducer.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        // set io paths
        FileInputFormat.addInputPath(job, new Path("/geosales.csv"));
        FileOutputFormat.setOutputPath(job, new Path("/minMaxUnitsSold1"));

        System.exit(job.waitForCompletion(true)? 0 : 1);
    }
}
