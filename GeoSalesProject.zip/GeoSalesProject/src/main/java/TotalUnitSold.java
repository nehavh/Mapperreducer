
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TotalUnitSold {
    public static class CountMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            // split a line into words
            String[] words = value.toString().trim().split(",");

            String country = words[2];
            String unitSold = words[9];
            String itemType = words[3];
            String orderDate = words[6];
            String orderYear = "";
            // output (word, 1)
            if (!orderDate.equals("order_date")) {
                LocalDate date = LocalDate.parse(orderDate, formatter);

                orderYear = String.valueOf(date.getYear());
            }
            String outKey = String.format("%s|%s|%s", country, itemType, orderYear);
            if (!unitSold.equals("units_sold")){
                context.write(new Text(outKey), new IntWritable(Integer.parseInt(unitSold)));
            }

            // output (word, 1)
        }
    }
    public static class CountReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            // sum up counts for the key
            int sum = 0;
            //int cnt = 0;
            for (IntWritable value : values) {
                sum += value.get();
            }
            //sum /= cnt;
            // output (word, count)
            context.write(key, new IntWritable(sum));
        }
    }
}
