import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;


public class TopOrderIds {
    public static class CountMapper extends Mapper<LongWritable, Text, DoubleWritable, Text> {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            // split a line into words
            String[] words = value.toString().trim().split(",");

            Configuration conf = context.getConfiguration();
            String year = conf.get("year");

            String orderId = words[7];
            String totalProfit = words[14];
            String orderDate = words[6];
            String orderYear = "";

            // output (word, 1)
            if (!orderDate.equals("order_date")) {
                LocalDate date = LocalDate.parse(orderDate, formatter);

                orderYear = String.valueOf(date.getYear());
            }


            if (!orderDate.equals("order_date") && orderYear.equals(year) && !totalProfit.equals("total_profit")) {
                double totalProfitDbl = (-1) * Double.parseDouble(totalProfit);
                context.write(new DoubleWritable(totalProfitDbl), new Text(orderId + " " +year));
            }

        }
    }

    public static class CountReducer extends Reducer<DoubleWritable, Text, DoubleWritable, Text> {
        static int count;
        @Override
        public void setup(Context context) throws IOException,
                InterruptedException
        {
            count = 0;
        }

        @Override
        public void reduce(DoubleWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

            // key                  values
            //-ve of no_of_views    [ movie_name ..]
            double no_of_views = (-1) * key.get();

            String movie_name = null;

            for (Text val : values)
            {
                movie_name = val.toString();
            }

            // we just write 10 records as output
            if (count < 10)
            {
                context.write(new DoubleWritable(no_of_views),
                        new Text(movie_name));
                count++;
            }
        }
    }
}