import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Driver4 {
    public static  void main(String[] args) throws Exception {
        // instantiate a configuration
        Configuration configuration = new Configuration();

        String year = args[0];
        configuration.set("year", year);

        // instantiate a job
        Job job = Job.getInstance(configuration, "Top 10 Order Ids");

        // set job parameters
        //job.setPartitionerClass(CustomPartitioner.class);
        job.setJarByClass(Driver4.class);
        job.setMapperClass(TopOrderIds.CountMapper.class);
        // job.setCombinerClass(MinMaxUnitsSold.CountReducer.class);
        job.setReducerClass(TopOrderIds.CountReducer.class);
        job.setMapOutputKeyClass(DoubleWritable.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(DoubleWritable.class);
        job.setOutputValueClass(Text.class);

        // set io paths
        FileInputFormat.addInputPath(job, new Path("/geosales.csv"));
        FileOutputFormat.setOutputPath(job, new Path("/Top10orderids"));

        System.exit(job.waitForCompletion(true)? 0 : 1);
    }
}
