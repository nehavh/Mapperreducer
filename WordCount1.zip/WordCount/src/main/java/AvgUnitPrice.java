import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AvgUnitPrice {

    public static class CountMapper extends Mapper<LongWritable, Text, Text, FloatWritable> {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            // split a line into words
            String[] words = value.toString().trim().split(",");

            String country = words[2];
            String unitPrice = words[10];
            String itemType = words[3];
            String orderDate = words[6];
            String orderYear = "";
            // output (word, 1)

            if (!orderDate.equals("order_date")) {
                LocalDate date = LocalDate.parse(orderDate, formatter);

                orderYear = String.valueOf(date.getYear());
            }
//            U S|abc|2020   ---  23
//            US|abc|2020    ---  23
//            US|abc|2020    ---  23
//            US|abc|2020    ---  23
//            US|abc|2020    ---  23
//            US|abc|2020    ---  23

//            key, value
//            key, value
//            key, value
//            key, value
//            key, value
//            key, value

            String outKey = String.format("%s|%s|%s", country, itemType, orderYear);
            if (!unitPrice.equals("unit_price")){
                context.write(new Text(outKey), new FloatWritable(Float.parseFloat(unitPrice)));
            }

            // output (word, 1)
        }
    }

    public static class CountReducer extends Reducer<Text, FloatWritable, Text, FloatWritable> {
        @Override
        public void reduce(Text key, Iterable<FloatWritable> values, Context context) throws IOException, InterruptedException {
            // sum up counts for the key
            float sum = 0;
            int cnt = 0;
            for (FloatWritable value : values) {
                 cnt++;
                sum += value.get();
            }
             sum /= cnt;
            // output (word, count)
            context.write(key, new FloatWritable(sum));
        }
    }
}