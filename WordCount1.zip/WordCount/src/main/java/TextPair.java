import java.io.*;
import java.util.Objects;
import org.apache.hadoop.io.*;


public class TextPair implements WritableComparable<TextPair> {
    private LongWritable orderId;
    private DoubleWritable totalProfit;

    public TextPair() {
        this.orderId = new LongWritable(0L);
        this.totalProfit = new DoubleWritable(0D);
    }

    public TextPair(LongWritable orderId, DoubleWritable totalProfit) {
        this.orderId = orderId;
        this.totalProfit = totalProfit;
    }

    public void set(LongWritable orderId, DoubleWritable totalProfit) {
        this.orderId = orderId;
        this.totalProfit = totalProfit;
    }

    public LongWritable getOrderId() {
        return orderId;
    }

    public DoubleWritable getTotalProfit() {
        return totalProfit;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        orderId.write(out);
        totalProfit.write(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        orderId.readFields(in);
        totalProfit.readFields(in);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, totalProfit);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TextPair that = (TextPair) o;
        return Objects.equals(orderId, that.orderId) &&
                Objects.equals(totalProfit, that.totalProfit);

    }

    @Override
    public int compareTo(TextPair o) {
        int dist = Double.compare(this.getTotalProfit().get(),o.getTotalProfit().get());
        dist= dist==0 ? Long.compare(this.getOrderId().get(),o.orderId.get()):dist;
        if(dist==0){
            return this.getOrderId().toString().compareTo(o.orderId.toString());
        }else{
            return dist;
        }
    }
}