import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;


public class MinMaxUnitsSold {
    public static class CountMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            // split a line into words
            String[] words = value.toString().trim().split(",");

            String country = words[2];
            String unitSold = words[9];
            String itemType = words[3];
            String orderDate = words[6];
            String orderYear = "";
            // output (word, 1)
            if (!orderDate.equals("order_date")) {
                LocalDate date = LocalDate.parse(orderDate, formatter);

                orderYear = String.valueOf(date.getYear());
            }
            String outKey = String.format("%s|%s|%s", country, itemType, orderYear);
            if (!unitSold.equals("units_sold")) {
                context.write(new Text(outKey), new IntWritable(Integer.parseInt(unitSold)));
            }

            // output (word, 1)
        }
    }

    public static class CountReducer extends Reducer<Text, IntWritable, Text, Text> {
        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {

            // Stream<Integer> str = StreamSupport.stream(values.spliterator(), false).map(IntWritable::get);

            // Integer min = str.min(Integer::compare).orElse(null);
            // Integer max = str.max(Integer::compare).orElse(null);

            List<Integer> str = StreamSupport.stream(values.spliterator(), false).map(IntWritable::get).collect(Collectors.toList());

            Integer min = Collections.min(str);
            Integer max = Collections.max(str);

            String output = String.format("%s, %s", min, max);

            //sum /= cnt;
            // output (word, count)
            context.write(key, new Text(output));
        }
    }
}