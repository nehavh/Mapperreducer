import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;


public class TopOrderIds {
    public static class CountMapper extends Mapper<LongWritable, Text, Text, TextPair> {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        private TextPair pair = new TextPair();

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            // split a line into words
            String[] words = value.toString().trim().split(",");

//      String country = words[2];
            String orderId = words[7];
            String totalProfit = words[14];
            String orderDate = words[6];
            String orderYear = "";

            // output (word, 1)
            if (!orderDate.equals("order_date")) {
                LocalDate date = LocalDate.parse(orderDate, formatter);

                orderYear = String.valueOf(date.getYear());
            }

            if (!totalProfit.equals("total_profit")) {
                pair = new TextPair(new LongWritable(Long.parseLong(orderId)),
                        new DoubleWritable(Double.parseDouble(totalProfit)));
            }

//      String outKey = String.format("%s|%s|%s", country, itemType, orderYear);
            if (!orderDate.equals("order_date")) {
                context.write(new Text(orderYear), pair);
            }

            // output (word, 1)
        }
    }

    public static class CountReducer extends Reducer<Text, TextPair, Text, Text> {
        @Override
        public void reduce(Text key, Iterable<TextPair> values, Context context) throws IOException, InterruptedException {

            List<TextPair> pairList = new ArrayList<>();

            values.forEach(pairList::add);

            Collections.sort(pairList);
//            pairList.sort(reverseOrder(Comparator.nullsLast(comparing(TextPair::getTotalProfit))));

            pairList = pairList.subList(0, 9);

            List<LongWritable> idList = pairList.stream().map(TextPair::getOrderId).collect(Collectors.toList());

            String output = StringUtils.join(idList, ',');

            //sum /= cnt;
            // output (word, count)
            context.write(key, new Text(output));
        }
    }
}