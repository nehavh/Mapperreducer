import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Driver2 {
    public static  void main(String[] args) throws Exception {
        // instantiate a configuration
        Configuration configuration = new Configuration();

        // instantiate a job
        Job job = Job.getInstance(configuration, "Units sold");

        // set job parameters
        job.setJarByClass(TotalUnitSold.class);
        job.setMapperClass(TotalUnitSold.CountMapper.class);
        job.setCombinerClass(TotalUnitSold.CountReducer.class);
        job.setReducerClass(TotalUnitSold.CountReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        // set io paths
        FileInputFormat.addInputPath(job, new Path("/geosales.csv"));
        FileOutputFormat.setOutputPath(job, new Path("/TotalUnitsSold"));

        System.exit(job.waitForCompletion(true)? 0 : 1);
    }
}
