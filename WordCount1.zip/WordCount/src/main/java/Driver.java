import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Driver {
    public static  void main(String[] args) throws Exception {
        // instantiate a configuration
        Configuration configuration = new Configuration();

        // instantiate a job
        Job job = Job.getInstance(configuration, "Word Count");

        // set job parameters
        job.setJarByClass(AvgUnitPrice.class);
        job.setMapperClass(AvgUnitPrice.CountMapper.class);
        job.setCombinerClass(AvgUnitPrice.CountReducer.class);
        job.setReducerClass(AvgUnitPrice.CountReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(FloatWritable.class);

        // set io paths
        FileInputFormat.addInputPath(job, new Path("/geosales.csv"));
        FileOutputFormat.setOutputPath(job, new Path("/avgunitprice"));

        System.exit(job.waitForCompletion(true)? 0 : 1);
    }
}
